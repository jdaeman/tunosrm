// GPoint.h: interface for the GPoint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GPOINT_H__EE7622A7_5950_4F5D_B24C_4E7D7EDC22A9__INCLUDED_)
#define AFX_GPOINT_H__EE7622A7_5950_4F5D_B24C_4E7D7EDC22A9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include<math.h>

class GSize;

struct GPOINT
{
	double x;
	double y;
	double distance(GPOINT pt){return sqrt((x-pt.x)*(x-pt.x)+(y-pt.y)*(y-pt.y));}
};
class GPoint  
{
public:
	double Distance(const GPoint& point);
	GPoint();
	GPoint(double _x, double _y);

	double x;
	double y;

	GPoint& operator=(const CPoint& p);
	void operator +=(const GSize& s);
	void operator -=(GPoint p){x-=p.x; y-=p.y;};
	bool operator ==(const GPoint& p){return (x==p.x && y==p.y);};
	bool operator !=(const GPoint& p){return (x!=p.x || y!=p.y);;};
	//MEM_MGMT(GPoint);  //use macro LEDA_MEMORY

	friend GPoint operator-(const GPoint& p1, const GPoint& p2)
	{return GPoint(p1.x - p2.x, p1.y - p2.y);};

	void Serialize(CArchive& ar);
};

struct GVECTOR
{
	double vx;
	double vy;	
	GVECTOR(){};
	GVECTOR(GPOINT s_pt, GPOINT e_pt){ vx = e_pt.x - s_pt.x ; vy = e_pt.y - s_pt.y; }
	GVECTOR(double x, double y ){ vx =x ;vy = y; }
	void	SetVector( GPOINT s_pt, GPOINT e_pt ){ vx = e_pt.x - s_pt.x ; vy = e_pt.y - s_pt.y; }
	void	SetVector( double x, double y){vx = x ; vy = y;}
	GVECTOR	GetNormal() { GVECTOR norm ; double len = length();  norm.SetVector( vx/len, vy/len); return norm;}
	double	InnerProduct(GVECTOR vec){ return vx*vec.vx + vy*vec.vy ;}
	double	OuterProduct(GVECTOR vec){ return vx*vec.vy - vy*vec.vx ;}
	//double	distance(GPOINT pt){return sqrt((x-pt.x)*(x-pt.x)+(y-pt.y)*(y-pt.y))};
	double	length(){return sqrt( vx*vx + vy*vy);}
	double	Cos(GVECTOR vec){ return InnerProduct(vec) / (length()*vec.length());}
	double	Sin(GVECTOR vec){ return OuterProduct(vec) / (length()*vec.length());}
};
#endif // !defined(AFX_GPOINT_H__EE7622A7_5950_4F5D_B24C_4E7D7EDC22A9__INCLUDED_)
