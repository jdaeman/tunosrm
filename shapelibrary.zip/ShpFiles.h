#pragma once

// #include "NvCommon.h"
// #include "NvDocument.h"
#include <afxtempl.h>
#include "stdafx.h"

typedef CArray < GPOINT, GPOINT & > ArPoint;

typedef struct tag_STNmeaOnLine
{
	GPOINT  pt;
	GVECTOR vec;
	double	angle;
	double  length;
	int		sn;
	int		match_link_id ;
	int		org_link_id;
	long long stlink_id ;
	GPOINT	pt_on_link ;
	double dist_to_link;
	double len_on_link;
	double len_on_link_proj;
	double len_matched;
}STNmeaOnLine;


typedef CArray < STNmeaOnLine, STNmeaOnLine&> AR_NMEA_ON_LINE;


class CShpFile:public CESRIShapeFile
{
public:
	CShpFile(int nMaxDepth=7);
	virtual ~CShpFile(void);

	int				AddRecord();
	CESRIShapeFile * CreateShpFile(char *pFilePath);


};


struct ST_RPRST_LINE
{
	int			iSN; // ����
	int			iLinkID;
	long long	llSTLinkID;//ǥ�ظ�ũ id
	int			iLiveSpeed;
	int			iDist;
	int			iPassTime ; //unit : sec
	const char*		szRoadName;
	int			iRoadType;
	int			iFacil_Type;
	int			iTotal_Rate;
	long long	llMLinkID;
	int			iDir;


	ST_RPRST_LINE(){Clear();}
	virtual ~ST_RPRST_LINE(){Clear();}
	void Clear(){memset(this, 0x00, sizeof(ST_RPRST_LINE));}
};

struct ST_RP_MATCH_RST
{
	float		fMatchRate;
	int			nPasstime1;
	int			nPasstime2;
	int			nDist1;
	int			nDist2;
	int			nTotalRate1;
	int			nTotalRate2;
	int			nMCostMrp;
	int			nMCostFrp;
	int			nFCostMrp;
	int			nFCostFrp;
	bool		bStartMapMatchFail;
	bool		bGoalMapMatchFail;
	int			nProctime;

	ST_RP_MATCH_RST()
	{
		fMatchRate = 0;
		nPasstime1 = 0;
		nPasstime2 = 0;
		nDist1 = 0;
		nDist2 = 0;
		nTotalRate1 = 0;
		nTotalRate2 = 0;
		nMCostMrp = 0;
		nMCostFrp = 0;
		nFCostMrp = 0;
		nFCostFrp = 0;
		nProctime = 0;
	}
	void Clear() { memset(this, 0x00, sizeof(ST_RP_MATCH_RST)); }
};

struct ST_RP_MATCH_RST3
{
	ST_RP_MATCH_RST xTSMatchRst;
	ST_RP_MATCH_RST xTBMatchRst;
	ST_RP_MATCH_RST xSBMatchRst;
};

struct ST_RPRST_LINE2
{
	int			iSN; // ����
	int			iLinkID;
	int			iLiveSpeed;
	int			iPatternValue;
	double		dfDist;
	int			iPassTime ; //unit : sec
	time_t		llGpsTime;
	unsigned char ture_state;
	unsigned char state;
	unsigned char	dummy[2];
	GPOINT pt_gps_kt;
	GVECTOR gvLine;

	//��κ񱳸� ���� �ʵ� �߰�
	long long	llSTLinkID;//ǥ�ظ�ũ id
	int			iDist;
	int			iRoadType;
	int			iFacilType;
	int			iToalRate;
	long long	llMlLnkID;
	int			iDir;

	ST_RPRST_LINE2(){Clear();}
	virtual ~ST_RPRST_LINE2(){}
	void Clear(){}
};

typedef CArray <ST_RPRST_LINE2, ST_RPRST_LINE2&> AR_RPRST_DBF;

class CSFRpRstLine:public CESRIShapeFile
{
public:
	CString m_strFilePath ;
	CSFRpRstLine(int nMaxDepth=7);
	virtual ~CSFRpRstLine(void);
	CArrSHPObject	m_arLinkShp;
	AR_RPRST_DBF	m_arRpRstDbf;

	bool			CreateShpFileW( CString strFilePath );
	int				AddRecord( CSHPObject *pShpObj, ST_RPRST_LINE *pDbf  );
	int				ReadRecord( int row_idx,  CSHPObject *pShpObj, ST_RPRST_LINE * pDbf);
	int				ReadRecord( int row_ofs, CSHPObject **ppShpObj ,ST_RPRST_LINE2 *pLink);
	bool			CreateShpFile( char *pFilePath );
	void			ReleaseShpArray();
};


class CSFVNmeaPoint:public CESRIShapeFile
{
public:
	CString m_strFilePath ;
	CSFVNmeaPoint(int nMaxDepth=7);
	virtual ~CSFVNmeaPoint(void);

	int				AddRecord( STNmeaOnLine *pDbf  );
	int				ReadRecord( int row_idx,   STNmeaOnLine * pDbf);
	bool			CreateShpFile( char *pFilePath );
	bool			CreateShpFileW( CString strFilePath );
};

class CSFMatchGuideLine:public CESRIShapeFile
{
public:
	CString m_strFilePath ;
	CSFMatchGuideLine(int nMaxDepth=7);
	virtual ~CSFMatchGuideLine(void);

	int				AddRecord( CSHPObject *pShpObj, STNmeaOnLine *pDbf  );
	int				ReadRecord( int row_idx,  CSHPObject *pShpObj, STNmeaOnLine * pDbf);
	bool			CreateShpFile( char *pFilePath );
	bool			CreateShpFileW( CString strFilePath );
};

