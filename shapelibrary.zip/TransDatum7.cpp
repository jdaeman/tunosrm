#include "stdafx.h"
#include "Projection.h"
#include "ProjDef.h"
#include <math.h>

//
// 7 Parameter Datum Converter
//

// WGS ������ǥ�� ����� ������ǥ�� ��ȯ��, Bursa��
// �Է�
//    xw,yw,zw : WGS ������ǥ
//    dx, dy, dz, omega, Phi, kappa, ds : 7 Parameter
// ���
//    xb,yb,zb : ����� ������ǥ
void TransBursa( double xw, double yw, double zw, double &xb, double &yb, double &zb, 
				 double dx, double dy, double dz, double omega, double Phi, double kappa, double ds )
{
	// XB = (1+ts){R}XW + tx
	double TKAPPA, TOMEGA, TPHI, TS;
	TOMEGA = I_GPN2RAD( omega / 3600 );
    TPHI   = I_GPN2RAD( Phi   / 3600 );
    TKAPPA = I_GPN2RAD( kappa / 3600 );
    TS     = ds * 0.000001;

	xb = (1 + TS) * (xw + TKAPPA * yw - TPHI * zw)      + dx;
	yb = (1 + TS) * (-1*TKAPPA * xw + yw + TOMEGA * zw) + dy;
	zb = (1 + TS) * (TPHI * xw - TOMEGA * yw + zw)      + dz;
}

void TransBursas( int numPoints, const double *xw, const double *yw, const double *zw, double *xb, double *yb, double *zb, 
				 double dx, double dy, double dz, double omega, double Phi, double kappa, double ds )
{
	// XB = (1+ts){R}XW + tx
	double TKAPPA, TOMEGA, TPHI, TS;
	TOMEGA = I_GPN2RAD( omega / 3600 );
    TPHI   = I_GPN2RAD( Phi   / 3600 );
    TKAPPA = I_GPN2RAD( kappa / 3600 );
    TS     = ds * 0.000001;

	for( int n=0; n<numPoints; n++ ) {
		xb[n] = (1 + TS) * (xw[n] + TKAPPA * yw[n] - TPHI * zw[n])      + dx;
		yb[n] = (1 + TS) * (-1*TKAPPA * xw[n] + yw[n] + TOMEGA * zw[n]) + dy;
		zb[n] = (1 + TS) * (TPHI * xw[n] - TOMEGA * yw[n] + zw[n])      + dz;
	}
}

// ������ǥ�� ����� WGS ������ǥ�� �� ��ȯ��, Bursa��
// �Է�
//   xb,yb,zb : ����� ������ǥ
// ���
//   xw,yw,zw : WGS ������ǥ
void InverseBursa( double xb, double yb, double zb, double &xw, double &yw, double &zw,
				 double dx, double dy, double dz, double omega, double Phi, double kappa, double ds )
{
	// XW = 1/(1+ts) {R}^-1 {XB - tx} 
	double xt, yt, zt;
	xt = xb - dx;
	yt = yb - dy;
	zt = zb - dz;

	double TKAPPA, TOMEGA, TPHI, TS;
	TOMEGA = I_GPN2RAD( omega / 3600 );
    TPHI   = I_GPN2RAD( Phi   / 3600 );
    TKAPPA = I_GPN2RAD( kappa / 3600 );
    TS     = ds * 0.000001;
   
	xw = 1 / (1 + TS) * (xt - TKAPPA * yt + TPHI * zt);
	yw = 1 / (1 + TS) * (TKAPPA   * xt + yt - TOMEGA * zt);
	zw = 1 / (1 + TS) * (-1 *TPHI * xt + TOMEGA * yt + zt);
}

void InverseBursas( int numPoints, const double *xb, const double *yb, const double *zb, double *xw, double *yw, double *zw,
				 double dx, double dy, double dz, double omega, double Phi, double kappa, double ds )
{
	// XW = 1/(1+ts) {R}^-1 {XB - tx} 
	double TKAPPA, TOMEGA, TPHI, TS;
	TOMEGA = I_GPN2RAD( omega / 3600 );
    TPHI   = I_GPN2RAD( Phi   / 3600 );
    TKAPPA = I_GPN2RAD( kappa / 3600 );
    TS     = ds * 0.000001;

	for( int n=0; n<numPoints; n++ ) {
		double xt, yt, zt;
		xt = xb[n] - dx;
		yt = yb[n] - dy;
		zt = zb[n] - dz;
   
		xw[n] = 1 / (1 + TS) * (xt - TKAPPA * yt + TPHI * zt);
		yw[n] = 1 / (1 + TS) * (TKAPPA   * xt + yt - TOMEGA * zt);
		zw[n] = 1 / (1 + TS) * (-1 *TPHI * xt + TOMEGA * yt + zt);
	}
}

inline double fnSPHSN( double a, double es, double sphi )
{
	return a / sqrt( 1 - es * sin( sphi )*sin( sphi ) );
}

// GRS80 ������ǥ�� ����� ������ǥ�� ��ȯ��, Molodensky-Badekas
// �Է�
//   xw,yw,zw : GRS ������ǥ
// ���
//   xb,yb,zb : ����� ������ǥ
void InverseMolodenskyBadekas( double xw, double yw, double zw, double &xb, double &yb, double &zb, double xa, double ya, double za, double dx, double dy, double dz, double omega, double Phi, double kappa, double ds )
{
	// XW = XA + dX + 1/(1+ts){R}^-1{XB-XA}
	double TKAPPA, TOMEGA, TPHI, TS;
	TOMEGA = I_GPN2RAD( omega / 3600 );
    TPHI   = I_GPN2RAD( Phi   / 3600 );
    TKAPPA = I_GPN2RAD( kappa / 3600 );
    TS     = ds * 0.000001;

	double xt = xw - xa;
	double yt = yw - ya;
	double zt = zw - za;
	xb = xa + dx + 1 / (1 + TS) * (xt - TKAPPA * yt + TPHI * zt);
	yb = ya + dy + 1 / (1 + TS) * (TKAPPA   * xt + yt - TOMEGA * zt);
	zb = za + dz + 1 / (1 + TS) * (-1 *TPHI * xt + TOMEGA * yt + zt);
}

void InverseMolodenskyBadekas_s( int numPoints, const double *xw, const double *yw, const double *zw, double *xb, double *yb, double *zb, double xa, double ya, double za, double dx, double dy, double dz, double omega, double Phi, double kappa, double ds )
{
	// XW = XA + dX + 1/(1+ts){R}^-1{XB-XA}
	double TKAPPA, TOMEGA, TPHI, TS;
	TOMEGA = I_GPN2RAD( omega / 3600 );
    TPHI   = I_GPN2RAD( Phi   / 3600 );
    TKAPPA = I_GPN2RAD( kappa / 3600 );
    TS     = ds * 0.000001;

	for( int n=0; n<numPoints; n++ ) {
		double xt = xw[n] - xa;
		double yt = yw[n] - ya;
		double zt = zw[n] - za;
		xb[n] = xa + dx + 1 / (1 + TS) * (xt - TKAPPA * yt + TPHI * zt);
		yb[n] = ya + dy + 1 / (1 + TS) * (TKAPPA   * xt + yt - TOMEGA * zt);
		zb[n] = za + dz + 1 / (1 + TS) * (-1 *TPHI * xt + TOMEGA * yt + zt);
	}
}

// ����� ������ǥ�� GRS80 ������ǥ�� ��ȯ��, Molodensky-Badekas
// �Է�
//   xb,yb,zb : ����� ������ǥ
// ���
//   xw,yw,zw : GRS ������ǥ
void ForwordMolodenskyBadekas( double xb, double yb, double zb, double &xw, double &yw, double &zw, double xa, double ya, double za, double dx, double dy, double dz, double omega, double Phi, double kappa, double ds )
{
	// XW = XA + dX + (1+ts){R}{XB-XA}
	double TKAPPA, TOMEGA, TPHI, TS;
	TOMEGA = I_GPN2RAD( omega / 3600 );
    TPHI   = I_GPN2RAD( Phi   / 3600 );
    TKAPPA = I_GPN2RAD( kappa / 3600 );
    TS     = ds * 0.000001;

	double tx = xb - xa;
	double ty = yb - ya;
	double tz = zb - za;
	xw = xa + dx + (1 + TS) * (tx + TKAPPA * ty - TPHI * tz);
	yw = ya + dy + (1 + TS) * (-1*TKAPPA * tx + ty + TOMEGA * tz);
	zw = za + dz + (1 + TS) * (TPHI * tx - TOMEGA * ty + tz);
}

void ForwordMolodenskyBadekas_s( int numPoints, const double *xb, const double *yb, const double *zb, double *xw, double *yw, double *zw, double xa, double ya, double za, double dx, double dy, double dz, double omega, double Phi, double kappa, double ds )
{
	// XW = XA + dX + (1+ts){R}{XB-XA}
	double TKAPPA, TOMEGA, TPHI, TS;
	TOMEGA = I_GPN2RAD( omega / 3600 );
    TPHI   = I_GPN2RAD( Phi   / 3600 );
    TKAPPA = I_GPN2RAD( kappa / 3600 );
    TS     = ds * 0.000001;

	for( int n=0; n<numPoints; n++ ) {
		double tx = xb[n] - xa;
		double ty = yb[n] - ya;
		double tz = zb[n] - za;
		xw[n] = xa + dx + (1 + TS) * (tx + TKAPPA * ty - TPHI * tz);
		yw[n] = ya + dy + (1 + TS) * (-1*TKAPPA * tx + ty + TOMEGA * tz);
		zw[n] = za + dz + (1 + TS) * (TPHI * tx - TOMEGA * ty + tz);
	}
}

//
// �������� ������ǥ�� �ٲ�
// �Է� parameter
// phi  : ����
// lam  : �浵
// a    : ��ݰ�
// f    : ������ (1/299.....)
// ��� ���
//  x, y, z : ������ǥ  x(north), y(east), z
//
//
void GP2CTR( double Phi, double Lam, double h, double a, double f, double &x, double &y, double &z )
{
	double sphi, slam, recf, b, es, n;
   
	double degrad = atan(1.0) / 45.0;
	sphi   = I_GPN2RAD( Phi );
	slam   = I_GPN2RAD( Lam );

	//�ܹݰ� b#, Ⱦ��� �ݰ� N�� ���
	//** SEMI MAJOR AXIS - B **
	recf = 1 / f;
	b    = a * (recf - 1) / recf;
	es   = (a * a - b * b ) / ( a * a );
    
	//Ⱦ��� �ݰ�
	n    = fnSPHSN( a, es, sphi );
   
	//'x, y, z�� ���
	x = (n + h) * cos(sphi) * cos(slam);
	y = (n + h) * cos(sphi) * sin(slam);
	z = ( (b*b) / (a*a) * n + h) * sin(sphi);
}

void GP2CTRs( int numPoints, const double *Phi, const double *Lam, const double *h, double a, double f, double *x, double *y, double *z )
{
	double sphi, slam, recf, b, es, nn;
   
	double degrad = atan(1.0) / 45.0;

	//�ܹݰ� b#, Ⱦ��� �ݰ� N�� ���
	//** SEMI MAJOR AXIS - B **
	recf = 1 / f;
	b    = a * (recf - 1) / recf;
	es   = (a * a - b * b ) / ( a * a );

	for( int n=0; n<numPoints; n++ ) {
		sphi   = I_GPN2RAD( Phi[n] );
		slam   = I_GPN2RAD( Lam[n] );
    
		//Ⱦ��� �ݰ�
		nn    = fnSPHSN( a, es, sphi );
   
		//'x, y, z�� ���
		x[n] = (nn + h[n]) * cos(sphi) * cos(slam);
		y[n] = (nn + h[n]) * cos(sphi) * sin(slam);
		z[n] = ( (b*b) / (a*a) * nn + h[n]) * sin(sphi);
	}
}


// ������ǥ�� ������ ��ǥ�� �ٲ�
// �Է� parameter
// x, y, z : ������ǥ  x(north), y(east), z
// a    : ��ݰ�
// f    : ������ (1/299.....)
// ��� ���
//   phi#  : ����
//   lam#  : �浵
void CTR2GP( double x, double y, double z, double a, double f, double &Phi, double &Lam, double &h )
{
	double sphiold, sphinew, slam, recf, b, es, n, p;

    // �ܹݰ� b#, Ⱦ��� �ݰ� N�� ���
    //     ** SEMI MAJOR AXIS - B **
    recf = 1 / f;
	b    = a * (recf - 1) / recf;
    es   = (a * a - b * b ) / ( a * a );

    //�浵 ���
    slam = atan( y / x );
   
    //���� �� Ÿ��ü ���� ���
    p = sqrt( x * x + y * y);
   
	// 1�� ������
    h		= 0;
	sphiold = atan( z / p );
	n = fnSPHSN( a, es, sphiold );

	// ������ 10^-12�̳� �϶����� �ݺ����
    for( int i=0; i<30; i++ ) {
		sphinew= atan( z/(p-es*n*cos(sphiold)) );
		if( i>0 && fabs( sphinew - sphiold ) < 1E-18 )
			break;
		// �� Ⱦ��� �ݰ� �� h
		n = fnSPHSN( a, es, sphinew );
		h = p / cos( sphinew ) - n;
		sphiold = sphinew;
	}

/*
	double theta      = atan( (z*a) / (p*b) );
	double sin_theta3 = sin(theta) * sin(theta) * sin(theta);
	double cos_theta3 = cos(theta) * cos(theta) * cos(theta);
 	sphinew = atan( (z+es*b*sin_theta3) / (p-es*a*cos_theta3) );
*/
	Phi = I_RAD2GPN( sphinew );
	Lam = I_RAD2GPN( slam );

	double degrad = atan(1.0) / 45.0;
	Phi = sphinew  / degrad;
	Lam = slam     / degrad;

	if( x < 0 ) 
		Lam = 180 + Lam; // 90�� - 270 ����
	if( Lam < 0 ) 
	    Lam = 360 + Lam; // 270�� - 360 ����
}

void CTR2GPs( int numPoints, const double *x, const double *y, const double *z, double a, double f, double *Phi, double *Lam, double *h )
{
	double sphiold, sphinew, slam, recf, b, es, nn, p;

    // �ܹݰ� b#, Ⱦ��� �ݰ� N�� ���
    //     ** SEMI MAJOR AXIS - B **
    recf = 1 / f;
	b    = a * (recf - 1) / recf;
    es   = (a * a - b * b ) / ( a * a );
	double degrad = atan(1.0) / 45.0;

	for( int n=0; n<numPoints; n++ ) {
		//�浵 ���
		slam = atan( y[n] / x[n] );
   
		//���� �� Ÿ��ü ���� ���
		p = sqrt( x[n] * x[n] + y[n] * y[n]);
   
		// 1�� ������
		h[n]		= 0;
		sphiold = atan( z[n] / p );
		nn = fnSPHSN( a, es, sphiold );

		// ������ 10^-12�̳� �϶����� �ݺ����
		for( int i=0; i<30; i++ ) {
			sphinew= atan( z[n]/(p-es*nn*cos(sphiold)) );
			if( i>0 && fabs( sphinew - sphiold ) < 1E-18 )
				break;
			// �� Ⱦ��� �ݰ� �� h
			nn = fnSPHSN( a, es, sphinew );
			h[n] = p / cos( sphinew ) - nn;
			sphiold = sphinew;
		}

	/*
		double theta      = atan( (z*a) / (p*b) );
		double sin_theta3 = sin(theta) * sin(theta) * sin(theta);
		double cos_theta3 = cos(theta) * cos(theta) * cos(theta);
 		sphinew = atan( (z+es*b*sin_theta3) / (p-es*a*cos_theta3) );
	*/
		Phi[n] = I_RAD2GPN( sphinew );
		Lam[n] = I_RAD2GPN( slam );

		Phi[n] = sphinew  / degrad;
		Lam[n] = slam     / degrad;

		if( x[n] < 0 ) 
			Lam[n] = 180 + Lam[n]; // 90�� - 270 ����
		if( Lam < 0 ) 
			Lam[n] = 360 + Lam[n]; // 270�� - 360 ����
	}
}

/* Bessel <==> WGS84
	a) 128.535, -482.401, -664.745, 2.2004, 0.2038, -3.483, -0.3281 : �Ǵ������ Moldensky 
	b) 199.538, -467.589, -607.207, 2.2004, 0.2038, -3.483, -0.3281 : �Ǵ������ Bursa
	c) 127.046, -478.916, -665.615, -2.156, -2.341, 1.714, -5.626   : �ӿ������
	d) 146.44, -507.89, -681.46, 0, 0, 0, 0 :  ���� �۾����� 
	e) 147, -506, -687, 0, 0, 0, 0 : �̱� ���α׷� , Tokyo datum, south Korea
	f) 144.778, -503.702, -684.67, 0, 0, 0, 0 :  �ӿ��� ���� 
	g) 105.627, -462.37, -643.258, 0, 0, 0, 0 : GPS Korea 
*/
void WGP2BGP( double xw, double yw, double zw, double &xb, double &yb, double &zb )
{
	double x, y, z, tx, ty, tz;
	GP2CTR( xw, yw, zw, WGS84_AXIS, WGS84_FLAT, x, y, z );

	double dx, dy, dz;
	dx = 146; dy = -507; dz = -687;
	TransBursa( x, y, z, tx, ty, tz,
				 dx, dy, dz, 0, 0, 0, 0 );
	CTR2GP( tx, ty, tz, BESSEL_AXIS, BESSEL_FLAT, xb, yb, zb );
}

void BGP2WGP( double xb, double yb, double zb, double &xw, double &yw, double &zw )
{
	double x, y, z, tx, ty, tz;
	GP2CTR( xb, yb, zb, BESSEL_AXIS, BESSEL_FLAT, x, y, z );

	double dx, dy, dz;
	dx = 146; dy = -507; dz = -687;
	InverseBursa( x,  y,  z, tx, ty, tz,
				  dx, dy, dz, 0, 0, 0, 0 );
	CTR2GP( tx, ty, tz, WGS84_AXIS, WGS84_FLAT, xw, yw, zw );
}

void WGP2BGPs( int numPoints, const double *xw, const double *yw, const double *zw, double *xb, double *yb, double *zb )
{
	double *x, *y, *z, *tx, *ty, *tz;
	x = new double [ numPoints ];
	y = new double [ numPoints ];
	z = new double [ numPoints ];
	tx = new double [ numPoints ];
	ty = new double [ numPoints ];
	tz = new double [ numPoints ];

	GP2CTRs( numPoints, xw, yw, zw, WGS84_AXIS, WGS84_FLAT, x, y, z );

	double dx, dy, dz;
	dx = 146; dy = -507; dz = -687;
	TransBursas( numPoints, x, y, z, tx, ty, tz,
				 dx, dy, dz, 0, 0, 0, 0 );
	CTR2GPs( numPoints, tx, ty, tz, BESSEL_AXIS, BESSEL_FLAT, xb, yb, zb );

	delete []x;
	delete []y;
	delete []z;
	delete []tx;
	delete []ty;
	delete []tz;
}

void BGP2WGPs( int numPoints, const double *xb, const double *yb, const double *zb, double *xw, double *yw, double *zw )
{
	double *x, *y, *z, *tx, *ty, *tz;
	x = new double [ numPoints ];
	y = new double [ numPoints ];
	z = new double [ numPoints ];
	tx = new double [ numPoints ];
	ty = new double [ numPoints ];
	tz = new double [ numPoints ];

	GP2CTRs( numPoints, xb, yb, zb, BESSEL_AXIS, BESSEL_FLAT, x, y, z );

	double dx, dy, dz;
	dx = 146; dy = -507; dz = -687;
	InverseBursas( numPoints, x,  y,  z, tx, ty, tz,
				  dx, dy, dz, 0, 0, 0, 0 );
	CTR2GPs( numPoints, tx, ty, tz, WGS84_AXIS, WGS84_FLAT, xw, yw, zw );

	delete []x;
	delete []y;
	delete []z;
	delete []tx;
	delete []ty;
	delete []tz;
}

void GGP2BGP_( double x, double y, double z, double &tx, double &ty, double &tz )
{
	double xa, ya, za;
	xa = -3159666.86;
	ya = 4068655.70;
	za = 3748799.65;

	double dx, dy, dz, omega, Phi, kappa, ds;
	dx = -145.907;  dy = 505.034; dz = 685.756;
	omega = -1.162; Phi = 2.347; kappa = 1.592;
	ds    = 6.342;
	InverseMolodenskyBadekas( x, y, z, tx, ty, tz, xa, ya, za, dx, dy, dz, omega, Phi, kappa, ds );
}

void BGP2GGP_( double x, double y, double z, double &tx, double &ty, double &tz )
{
	double xa, ya, za;
	xa = -3159521.31;
	ya = 4068151.32;
	za = 3748113.85;

	double dx, dy, dz, omega, Phi, kappa, ds;
	dx = -145.907;  dy = 505.034; dz = 685.756;
	omega = -1.162; Phi = 2.347; kappa = 1.592;
	ds    = 6.342;
	ForwordMolodenskyBadekas( x,  y,  z, tx, ty, tz, xa, ya, za, dx, dy, dz, omega, Phi, kappa, ds );
}

void GGP2BGP_s( int numPoints, const double *x, const double *y, const double *z, double *tx, double *ty, double *tz )
{
	double xa, ya, za;
	xa = -3159666.86;
	ya = 4068655.70;
	za = 3748799.65;

	double dx, dy, dz, omega, Phi, kappa, ds;
	dx = -145.907;  dy = 505.034; dz = 685.756;
	omega = -1.162; Phi = 2.347; kappa = 1.592;
	ds    = 6.342;
	InverseMolodenskyBadekas_s( numPoints, x, y, z, tx, ty, tz, xa, ya, za, dx, dy, dz, omega, Phi, kappa, ds );
}

void BGP2GGP_s( int numPoints, const double *x, const double *y, const double *z, double *tx, double *ty, double *tz )
{
	double xa, ya, za;
	xa = -3159521.31;
	ya = 4068151.32;
	za = 3748113.85;

	double dx, dy, dz, omega, Phi, kappa, ds;
	dx = -145.907;  dy = 505.034; dz = 685.756;
	omega = -1.162; Phi = 2.347; kappa = 1.592;
	ds    = 6.342;
	ForwordMolodenskyBadekas_s( numPoints, x,  y,  z, tx, ty, tz, xa, ya, za, dx, dy, dz, omega, Phi, kappa, ds );
}


//
// /* Bessel <==> GRS84
//    a) 145.907, -505.034, -685.756, 1.162, -2.347, -1.592, -6.342   : 2003�� ���ΰ���(GRS80)
//
void GGP2BGP( double xw, double yw, double zw, double &xb, double &yb, double &zb )
{
	double x, y, z, tx, ty, tz;
	GP2CTR( xw, yw, zw, GRS80_AXIS, GRS80_FLAT, x, y, z );

	GGP2BGP_( x, y, z, tx, ty, tz );

	CTR2GP( tx, ty, tz, BESSEL_AXIS, BESSEL_FLAT, xb, yb, zb );
}

void BGP2GGP( double xb, double yb, double zb, double &xw, double &yw, double &zw )
{
	double x, y, z, tx, ty, tz;
	GP2CTR( xb, yb, zb, BESSEL_AXIS, BESSEL_FLAT, x, y, z );

	BGP2GGP_( x, y, z, tx, ty, tz );

	CTR2GP( tx, ty, tz, WGS84_AXIS, WGS84_FLAT, xw, yw, zw );
}

void GGP2BGPs( int numPoints, const double *xw, const double *yw, const double *zw, double *xb, double *yb, double *zb )
{
	double *x, *y, *z, *tx, *ty, *tz;
	x = new double [ numPoints ];
	y = new double [ numPoints ];
	z = new double [ numPoints ];
	tx = new double [ numPoints ];
	ty = new double [ numPoints ];
	tz = new double [ numPoints ];

	GP2CTRs( numPoints, xw, yw, zw, GRS80_AXIS, GRS80_FLAT, x, y, z );

	GGP2BGP_s( numPoints, x, y, z, tx, ty, tz );

	CTR2GPs( numPoints, tx, ty, tz, BESSEL_AXIS, BESSEL_FLAT, xb, yb, zb );

	delete []x;
	delete []y;
	delete []z;
	delete []tx;
	delete []ty;
	delete []tz;
}

void BGP2GGPs( int numPoints, const double *xb, const double *yb, const double *zb, double *xw, double *yw, double *zw )
{
	double *x, *y, *z, *tx, *ty, *tz;
	x = new double [ numPoints ];
	y = new double [ numPoints ];
	z = new double [ numPoints ];
	tx = new double [ numPoints ];
	ty = new double [ numPoints ];
	tz = new double [ numPoints ];

	GP2CTRs( numPoints, xb, yb, zb, BESSEL_AXIS, BESSEL_FLAT, x, y, z );

	BGP2GGP_s( numPoints, x, y, z, tx, ty, tz );

	CTR2GPs( numPoints, tx, ty, tz, WGS84_AXIS, WGS84_FLAT, xw, yw, zw );

	delete []x;
	delete []y;
	delete []z;
	delete []tx;
	delete []ty;
	delete []tz;
}
