#include "StdAfx.h"
#include "StringConverter.h"

CStringConverter::CStringConverter(void)
{
}

CStringConverter::~CStringConverter(void)
{
}


BOOL CStringConverter::ToMultiByte(const CString& sText, /*out*/CStringA& sMultiChar)
{
	//int nLen = WideCharToMultiByte( CP_ACP, 0, sText, -1, NULL, 0, NULL, NULL );
	//char * pszBuf = new char[nLen + 1];
	//memset(pszBuf, 0, nLen + 1);
	//if (WideCharToMultiByte( CP_ACP, 0, sText, -1, pszBuf, nLen, NULL, NULL ) == 0)
	//{
	//	delete [] pszBuf;
	//	return FALSE;
	//}

	//sMultiChar = pszBuf;

	//delete [] pszBuf;

	return TRUE;
}

BOOL CStringConverter::ToMultiByte(wchar_t* szText, /*out*/CStringA& sMultiChar)
{
	int nLen = WideCharToMultiByte( CP_ACP, 0, szText, -1, NULL, 0, NULL, NULL );
	char * pszBuf = new char[nLen + 1];
	memset(pszBuf, 0, nLen + 1);
	if (WideCharToMultiByte( CP_ACP, 0, szText, -1, pszBuf, nLen, NULL, NULL ) == 0)
	{
		delete [] pszBuf;
		return FALSE;
	}

	sMultiChar = pszBuf;

	delete [] pszBuf;

	return TRUE;
}


int CStringConverter::Bin2Char( unsigned char *dest, unsigned char *src, int len )
{
	char        sTemp[ 4 ];

	dest[ 0 ] = 0x00;
	for(int i = 0;i < len; i++)
	{
		memset( sTemp, 0, sizeof(sTemp) );
		sprintf( sTemp, "%03d", ( unsigned char )src[ i ]);
		strcat( ( char * ) dest, sTemp );
	};

	return( strlen( ( char * ) dest ));
}