#include "stdafx.h"

CShpFile::CShpFile(int nMaxDepth):CESRIShapeFile(nMaxDepth)
{
}

CShpFile::~CShpFile(void)
{
}

CESRIShapeFile * CShpFile::CreateShpFile(char *pFilePath)
{
	return NULL;
}

int CShpFile::AddRecord()
{
	return 0;
}

//////////////////////////////////////////////////////////////////////////
// CSFRpRstLine
CSFRpRstLine::CSFRpRstLine(int nMaxDepth):CESRIShapeFile(nMaxDepth)
{
}

CSFRpRstLine::~CSFRpRstLine(void)
{
	ReleaseShpArray();
}

bool  CSFRpRstLine::CreateShpFileW( CString strFilePath )
{
	CStringA strPath;
	CStringConverter::ToMultiByte( strFilePath, strPath );
	return CreateShpFile( strPath.GetBuffer() );
}

void CSFRpRstLine::ReleaseShpArray()
{
	int count = m_arLinkShp.GetCount();
	for( int loop1 = 0  ; loop1 <  count ; loop1 ++ )
	{
		CSHPObject *pShp = m_arLinkShp.GetAt(loop1);
		if(pShp)
		{
			delete pShp ; pShp = 0 ;
		}
	}
	m_arLinkShp.RemoveAll();
	m_arRpRstDbf.RemoveAll();
}

bool  CSFRpRstLine::CreateShpFile( char *pFilePath )
{

	//CString m_strFilePath  = pFilePath;

	//NvDocument * pDoc = NvDocument::GetInstance();

	try
	{
		//if( pSFLink->SHPCreate(  pDoc->m_strPathLinkShp, SHPT_ARCZ ) == NULL )
		if( SHPCreate(  pFilePath, SHPT_LINE ) == NULL )
		{
			throw -1;	
		}

		if ( DBFCreate( pFilePath ) == NULL )
		{
			throw -12;
		}
		DBFAddField("SN", FTInteger, 6, 0 );
		DBFAddField("LINK_ID", FTInteger, 10, 0 );
		DBFAddField("TPEG_ID", FTInteger, 10, 0 );
		DBFAddField("LIVE_SPD", FTInteger, 3, 0 );
		DBFAddField("DIST", FTInteger, 9, 0 );
		DBFAddField("PASS_TIME", FTInteger, 6, 0 );
		DBFAddField("ROAD_NM", FTString, 50, 0 );
		DBFAddField("ROAD_TYPE", FTInteger, 3, 0 );
		DBFAddField("FACIL_TYPE", FTInteger, 3, 0 );
		

	}
	catch (int e)
	{
		if(e < 0 )
		{
			return false;
		}
	}

	return true;
}

int	CSFRpRstLine::AddRecord(  CSHPObject *pShpObj, ST_RPRST_LINE *pDbf )
{
#if 1
	double dummy = 0 ;
	int		fld_idx =0 ;
	int loop1 = 0 ;
/* 
	for( loop1 = 0 ; loop1 < pLink->vertex_cnt ; loop1 ++ )
	{
		CGeoTrans::GeoTrans(PROJECTTYPE_WGS84, PROJECTTYPE_Katech, pLink->vertex[loop1].x, pLink->vertex[loop1].y, &pt.x, &pt.y);
		pLink->vertex[loop1].x	= pt.x;
		pLink->vertex[loop1].y	= pt.y;
	}
*/
	if( pShpObj->nSHPType == 13  ) pShpObj->nSHPType = 3;
	int row_ofs = SHPWriteObject(-1, pShpObj );

	DBFWriteAttribute(row_ofs,fld_idx++ , pDbf->iSN );
	DBFWriteAttribute(row_ofs,fld_idx++ , pDbf->iLinkID);
	DBFWriteAttribute(row_ofs,fld_idx++ , pDbf->llSTLinkID );
	DBFWriteAttribute(row_ofs, fld_idx++ , pDbf->iLiveSpeed);
	DBFWriteAttribute(row_ofs, fld_idx++ , pDbf->iDist);
	DBFWriteAttribute(row_ofs, fld_idx++ , pDbf->iPassTime);
	DBFWriteAttribute(row_ofs, fld_idx++ , pDbf->szRoadName);
	DBFWriteAttribute(row_ofs, fld_idx++ , pDbf->iRoadType);
	DBFWriteAttribute(row_ofs, fld_idx++ , pDbf->iFacil_Type);
	DBFWriteAttribute(row_ofs, fld_idx++, pDbf->iTotal_Rate);

#endif
	return row_ofs ;
}

int				CSFRpRstLine::ReadRecord( int row_ofs, CSHPObject *pShpObj ,ST_RPRST_LINE *pLink )
{
	char	* pTxt = 0;
	int		fld_idx = 0;



	pLink->iSN = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->iLinkID = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->llSTLinkID = DBFReadInt64Attribute( row_ofs, fld_idx++);
	pLink->iLiveSpeed = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->iDist = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->iPassTime = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->szRoadName = DBFReadStringAttribute( row_ofs, fld_idx++);
	pLink->iRoadType = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->iFacil_Type = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->iTotal_Rate = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->llMLinkID = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->iDir = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	
	return row_ofs;
}

int CSFRpRstLine::ReadRecord( int row_ofs, CSHPObject **ppShpObj ,ST_RPRST_LINE2 *pLink )
{
	char	* pTxt = 0;
	int		fld_idx = 0;

	*ppShpObj = SHPReadObject(row_ofs);
	if( *ppShpObj == NULL ) return -1 ;
	
	pLink->iSN = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->iLinkID = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->llSTLinkID = DBFReadInt64Attribute( row_ofs, fld_idx++);
	pLink->iLiveSpeed = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->iPatternValue = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->dfDist = DBFReadDoubleAttribute( row_ofs, fld_idx++);
	pLink->iPassTime = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	
	/*
	pLink->iSN = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->iLinkID = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->llSTLinkID = DBFReadInt64Attribute(row_ofs, fld_idx++);
	pLink->iLiveSpeed = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->iPatternValue = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->dfDist = DBFReadDoubleAttribute(row_ofs, fld_idx++);
	pLink->iDist = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->iPassTime = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->iRoadType = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->iFacilType = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->iToalRate = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	pLink->llMlLnkID = DBFReadIntegerAttribute(row_ofs, fld_idx++);
	*/
	return row_ofs;
}

CSFVNmeaPoint::CSFVNmeaPoint(int nMaxDepth):CESRIShapeFile(nMaxDepth)
{
}

CSFVNmeaPoint::~CSFVNmeaPoint(void)
{
}

bool  CSFVNmeaPoint::CreateShpFileW( CString strFilePath )
{
	CStringA strAFilePath;
	CStringConverter::ToMultiByte( strFilePath, strAFilePath );

	bool bCreate = CreateShpFile( strAFilePath.GetBuffer() );

	strAFilePath.ReleaseBuffer();

	return bCreate;
}


bool  CSFVNmeaPoint::CreateShpFile( char *pFilePath )
{

	try
	{
		//if( pSFLink->SHPCreate(  pDoc->m_strPathLinkShp, SHPT_ARCZ ) == NULL )
		if( SHPCreate(  pFilePath, SHPT_POINT ) == NULL )
		{
			throw -1;	
		}

		if ( DBFCreate( pFilePath ) == NULL )
		{
			throw -12;
		}
		DBFAddField("LINE_ID", FTInteger, 8, 0 );
		DBFAddField("SN", FTInteger, 8, 0 );
		DBFAddField("LENGTH", FTInteger, 8, 0 );
		DBFAddField("VX", FTDouble, 8, 3 );
		DBFAddField("VY", FTDouble, 8, 3 );
	}
	catch (int e)
	{
		if(e < 0 )
		{
			return false;
		}
	}

	return true;
}

int	CSFVNmeaPoint::AddRecord( STNmeaOnLine *pNmea )
{
#if 1
	CSHPObject *pshpObj = SHPCreateSimpleObject( SHPT_POINT, 1, &pNmea->pt.x, &pNmea->pt.y, NULL, NULL);
	double dummy = 0 ;


	int row_ofs = SHPWriteObject(-1,pshpObj );

	DBFWriteAttribute(row_ofs, 0 , pNmea->org_link_id );	
	DBFWriteAttribute(row_ofs, 1 , pNmea->sn );	
	DBFWriteAttribute(row_ofs, 2 , (int)pNmea->length );
	DBFWriteAttribute(row_ofs, 3 , pNmea->vec.vx );
	DBFWriteAttribute(row_ofs, 4 , pNmea->vec.vy );

	delete pshpObj ;
	pshpObj = NULL ;

#endif
	return row_ofs ;
}

int				CSFVNmeaPoint::ReadRecord( int row_ofs,   STNmeaOnLine * pDbf )
{
	char	* pTxt = 0;
	int		fld_idx = 0;

	CSHPObject * pShpObj = SHPReadObject(row_ofs);
	if( pShpObj == NULL ) return -1 ;
	pDbf->pt.x = pShpObj->pfX[0];
	pDbf->pt.y = pShpObj->pfY[0];
	pDbf->org_link_id = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pDbf->sn = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pDbf->length = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pDbf->vec.vx = DBFReadDoubleAttribute( row_ofs, fld_idx++);
	pDbf->vec.vy = DBFReadDoubleAttribute( row_ofs, fld_idx++);
	delete pShpObj; pShpObj = 0;

	return row_ofs;
}

bool  CSFMatchGuideLine::CreateShpFileW( CString strFilePath )
{
	CStringA strAFilePath;
	CStringConverter::ToMultiByte( strFilePath, strAFilePath );

	bool bCreate = CreateShpFile( strAFilePath.GetBuffer() );

	strAFilePath.ReleaseBuffer();

	return bCreate;
}

bool  CSFMatchGuideLine::CreateShpFile( char *pFilePath )
{

	try
	{
		//if( pSFLink->SHPCreate(  pDoc->m_strPathLinkShp, SHPT_ARCZ ) == NULL )
		if( SHPCreate(  pFilePath, SHPT_LINE ) == NULL )
		{
			throw -1;	
		}

		if ( DBFCreate( pFilePath ) == NULL )
		{
			throw -12;
		}
		DBFAddField("SN", FTInteger, 6, 0 );
		DBFAddField("ORLINK_ID", FTInteger, 10, 0 );
		DBFAddField("MTLINK_ID", FTInteger, 10, 0 );
		DBFAddField("DISTTOLINK", FTDouble, 9, 3 );
		DBFAddField("LENONLINK", FTDouble, 9, 3 );
		DBFAddField("LENMATCH", FTDouble, 9, 3 );
	}
	catch (int e)
	{
		if(e < 0 )
		{
			return false;
		}
	}

	return true;
}

CSFMatchGuideLine::CSFMatchGuideLine(int nMaxDepth):CESRIShapeFile(nMaxDepth)
{
}

CSFMatchGuideLine::~CSFMatchGuideLine(void)
{
}

int	CSFMatchGuideLine::AddRecord(  CSHPObject *pShpObj, STNmeaOnLine *pDbf )
{
#if 1
	double dummy = 0 ;
	int		fld_idx =0 ;
	int loop1 = 0 ;

	if( pShpObj->nSHPType == 13  ) pShpObj->nSHPType = 3;
	int row_ofs = SHPWriteObject(-1, pShpObj );

	DBFWriteAttribute(row_ofs,fld_idx++ , pDbf->sn );
	DBFWriteAttribute(row_ofs,fld_idx++ , pDbf->org_link_id );
	DBFWriteAttribute(row_ofs,fld_idx++ , pDbf->match_link_id);
	DBFWriteAttribute(row_ofs,fld_idx++ , pDbf->dist_to_link );
	DBFWriteAttribute(row_ofs, fld_idx++ , pDbf->len_on_link);
	DBFWriteAttribute(row_ofs, fld_idx++ , pDbf->len_matched);

#endif
	return row_ofs ;
}

int				CSFMatchGuideLine::ReadRecord( int row_ofs, CSHPObject *pShpObj ,STNmeaOnLine *pLink )
{
	char	* pTxt = 0;
	int		fld_idx = 0;

	pShpObj = SHPReadObject(row_ofs);
	if( pShpObj == NULL ) return -1 ;

	pLink->sn = DBFReadIntegerAttribute( row_ofs, fld_idx++);
	pLink->org_link_id = DBFReadInt64Attribute( row_ofs, fld_idx++);
	pLink->match_link_id = DBFReadInt64Attribute( row_ofs, fld_idx++);
	pLink->dist_to_link = DBFReadDoubleAttribute( row_ofs, fld_idx++);
	pLink->len_on_link= DBFReadDoubleAttribute( row_ofs, fld_idx++);
	pLink->len_matched= DBFReadDoubleAttribute( row_ofs, fld_idx++);

	return row_ofs;
}
