#pragma once

class CStringConverter
{
public:
	CStringConverter(void);
	~CStringConverter(void);

	static BOOL ToUnicode(const char* pszText, /*out*/CString& sUnicode);
	static BOOL ToMultiByte(const CString& sText, /*out*/CStringA& sMultiChar);
	static BOOL ToMultiByte(wchar_t* szText, /*out*/CStringA& sMultiChar);
	static int  Bin2Char( unsigned char *dest, unsigned char *src, int len );
};
