// ESRIShapeFile.h: interface for the CESRIShapeFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ESRISHAPEFILE_H__CF8C8C0A_6E29_4E84_A171_091870A43C61__INCLUDED_)
#define AFX_ESRISHAPEFILE_H__CF8C8C0A_6E29_4E84_A171_091870A43C61__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"

const double		ESRI_MEC_PI			= (3.14159265358979323846);
const double		ESRI_MEC_DEGREE		= (3.14159265358979323846/180.0);
const double		ESRI_MEC_IDEGREE		= (180.0/3.14159265358979323846);

typedef enum {stUNKNOWN, stPOINT,stPOLYLINE,stPOLYGON, stGRID} SHAPETYPE;

/************************************************************************/
/*                        Configuration options.                        */
/************************************************************************/

/* -------------------------------------------------------------------- */
/*      Should the DBFReadStringAttribute() strip leading and           */
/*      trailing white space?                                           */
/* -------------------------------------------------------------------- */
#define TRIM_DBF_WHITESPACE

/* -------------------------------------------------------------------- */
/*      Should we write measure values to the Multipatch object?        */
/*      Reportedly ArcView crashes if we do write it, so for now it     */
/*      is disabled.                                                    */
/* -------------------------------------------------------------------- */
#define DISABLE_MULTIPATCH_MEASURE

/* -------------------------------------------------------------------- */
/*      Shape types (nSHPType)                                          */
/* -------------------------------------------------------------------- */
#define SHPT_NULL	0
#define SHPT_POINT	1
#define SHPT_LINE	3
#define SHPT_POLYGON	5
#define SHPT_MULTIPOINT	8
#define SHPT_POINTZ	11
#define SHPT_ARCZ	13
#define SHPT_POLYGONZ	15
#define SHPT_MULTIPOINTZ 18
#define SHPT_POINTM	21
#define SHPT_ARCM	23
#define SHPT_POLYGONM	25
#define SHPT_MULTIPOINTM 28
#define SHPT_MULTIPATCH 31

/* -------------------------------------------------------------------- */
/*      Part types - everything but SHPT_MULTIPATCH just uses           */
/*      SHPP_RING.                                                      */
/* -------------------------------------------------------------------- */

#define SHPP_TRISTRIP	0
#define SHPP_TRIFAN	1
#define SHPP_OUTERRING	2
#define SHPP_INNERRING	3
#define SHPP_FIRSTRING	4
#define SHPP_RING	5


typedef enum {
		FTString,
		FTInteger,
		FTDouble,
		FTInvalid
} DBFFieldType;


/* -------------------------------------------------------------------- */
/*      CSHPObject - represents on shape (without attributes) read       */
/*      from the .shp file.                                             */
/* -------------------------------------------------------------------- */
class CSHPObject
{
public:
	CSHPObject();
	~CSHPObject();
	BOOL IsInRect(GPOINT pt, double tolerance );
	double GetLength();
	void Copy( CSHPObject *pShp );


public:
	int		nSHPType;
	
	int		nShapeId; /* -1 is unknown/unassigned */
	
	int		nParts;
	int		*panPartStart;
	int		*panPartType;
	
	int		vertex_cnt;
	double	*pfX;
	double	*pfY;
	double	*pfZ;
	double	*pfM;
	
	double	fxMin;
	double	fyMin;
	double	fzMin;
	double	fmidMin;
	
	double	fxMax;
	double	fyMax;
	double	fzMax;
	double	fmidMax;
} ;

typedef CArray<CSHPObject*, CSHPObject*> CArrSHPObject;
typedef CArray<CUIntArray*, CUIntArray*> CArrShpIdxList;


class CESRIShapeFile
{
public:
	CSHPObject * SHPCreateObject( int nSHPType, int nShapeId, int nParts, int * panPartStart, int * panPartType,
										int vertex_cnt, double * pfX, double * pfY, double * pfZ, double * pfM ,GPOINT *pt = NULL);
	CSHPObject * SHPCreateSimpleObject( int nSHPType, int vertex_cnt, double * pfX, double * pfY, double * pfZ ,GPOINT *pt = NULL);
	void SHPComputeExtents( CSHPObject * psObject );

	bool	HoleOuterPG( double *rgX, double *rgY, int ofs, int iVtxCnt );
	bool	GetOuterRingFlag_ShapePolyPart( CSHPObject *pShp , int *pOuter, int iOuterBufLen );

public:
	
	void SortByColumn(int nField, int* anSortedLink);
	void operator+=(CESRIShapeFile& o);
	CESRIShapeFile(int nMaxDepth=7);
	virtual ~CESRIShapeFile();
	int GetNaviIndexFromFile(const CString& sFileName);

	typedef	struct SHPInfo
	{
		FILE    *fpSHP;
		FILE	*fpSHX;
		
		int		nShapeType;				/* SHPT_* */
		
		int		nFileSize;				/* SHP file */
		
		int     nRecords;
		int		nMaxRecords;
		int		*panRecOffset;
		int		*panRecSize;
		
		double	adBoundsMin[4];
		double	adBoundsMax[4];
		
		int		bUpdated;
	};
	
	typedef SHPInfo * SHPHandle;
	
	/************************************************************************/
	/*                             DBF Support.                             */
	/************************************************************************/
	typedef	struct DBFInfo
	{
		FILE	*fp;
		
		int     nRecords;
		
		int		nRecordLength;
		int		nHeaderLength;
		int		nFields;
		int		*panFieldOffset;
		int		*panFieldSize;
		int		*panFieldDecimals;
		char	*pachFieldType;
		
		char	*pszHeader;
		
		int		nCurrentRecord;
		int		bCurrentRecordModified;
		char	*pszCurrentRecord;
		
		int		bNoHeader;
		int		bUpdated;
	};
	
	typedef DBFInfo * DBFHandle;
		
#define XBASE_FLDHDR_SZ       32
	
	/* -------------------------------------------------------------------- */
	/*      Shape quadtree indexing API.                                    */
	/* -------------------------------------------------------------------- */
	
	/* this can be two or four for binary or quad tree */
#define MAX_SUBNODE	4
	
	typedef struct shape_tree_node
	{
		/* region covered by this node */
		double	adfBoundsMin[4];
		double	adfBoundsMax[4];
		
		/* list of shapes stored at this node.  The papsShapeObj pointers
		or the whole list can be NULL */
		int		nOffset;//��Ʈ ���κ��� ��ȸ�� ���� nShapeCount�� ���� ��. .mbr���� �ε��̿����� ���
		int		nShapeCount;
		int		*panShapeIds;
		CSHPObject   **papsShapeObj;
		
		int		nSubNodes;
		struct shape_tree_node *apsSubNode[MAX_SUBNODE];
		
	} SHPTreeNode;
	
	typedef struct SHPTree
	{
		SHPHandle   hSHP;
		
		int		nMaxDepth;
		int		nDimension;
		
		SHPTreeNode	*psRoot;
	} ;
	
protected:
	CFile m_mbrFile;
	int m_nRef;
	CString m_sShapeFilePath;
    DBFHandle	m_hDBF;
	SHPHandle	m_hSHP;
	SHPTree	*m_hTree; //���� �ε��̿� Ʈ��
	SHAPETYPE	m_Type; //shape Ÿ��
	
	int m_nEntities;	//A pointer to an integer into which the number of
	//entities/structures should be placed.  May be NULL.
	int pnShapeType;	//A pointer to an integer into which the shapetype
	//of this file should be placed.  Shapefiles may contain
	//either SHPT_POINT, SHPT_LINE, SHPT_POLYGON or 
	//SHPT_MULTIPOINT entities.  This may be NULL.
	double padfMinBound[4];	//The X, Y, Z and M minimum values will be placed into
	//this four entry array.  This may be NULL.
	double padfMaxBound[4];	//The X, Y, Z and M maximum values will be placed into
	//this four entry array.  This may be NULL.
	DBFFieldType m_FieldType;
	int m_nField;
	GRect	m_grBoundary;
	int	m_nMaxDepth;
	int	m_nStringFieldLen;
	char * m_szStringField;
	double	m_retvalDoubleField;
	__int64 m_retvalLongLongField;
	int		m_retvalIntField;

public:
	int       DBFGetFieldIndex(const char *pszFieldName);
	void Close();
	//NaviIndex�� �����Ѵ�
	int GetNaviIndex();

	CFile* GetMBRFile();
	int Release();
	int AddRef();
	CString GetShapeFilePath();
	SHAPETYPE GetShapeType();
	GRect GetBoundary();
	int GetEntityCount() const;
	int GetLabelFieldIndex();

	SHPHandle		SHPOpen (const char* pszShapeFile, const char* pszAccess);
	//SHPHandle		SHPOpenW( const CString & strLayer, const char* pszAccess);
	CESRIShapeFile*	Open (const CString& sShapeFileName, BOOL bCreateTree = TRUE, const char* pszAccess="r");

	CSHPObject*		SHPReadObject (int iShape, BOOL bSetOuterRing = FALSE);
	int				SHPWriteObject (int iShape, CSHPObject* psObject);
	
	SHPHandle		GetSHPHandle();
	SHPTree*		GetSHPTree();
	int* SHPMBRShapes(double * padfBoundsMin, double * padfBoundsMax, int * pnShapeCount, CFile* pMBR, BOOL bSortByBottom = FALSE );

	int* SHPMBRShapes2(double * padfBoundsMin, double * padfBoundsMax, int * pnShapeCount, CArrSHPObject *pArrShpObj );
	
	int 	DBFReadIntegerAttribute( int iShape, int iField );
	long long  	DBFReadInt64Attribute( int iShape, int iField );
	double 	DBFReadDoubleAttribute( int iShape, int iField );
	const char * DBFReadStringAttribute( int iShape, int iField );
	int           DBFIsAttributeNULL( int iShape, int iField );
	int	      DBFGetFieldCount();
	DBFFieldType DBFGetFieldInfo( int iField, char * pszFieldName, int * pnWidth, int * pnDecimals );
	int	      DBFGetRecordCount();	
	CString GetQTreeFileName(const CString& sShpFilePath);
	BOOL CreateQTreeFile(const TCHAR* szFileName);
	CString GetMBRFileName(const CString &sShpFilePath);
	BOOL CreateMBRFile(const TCHAR *szFileName);
	void WriteMBRFile(SHPTreeNode * psTreeNode, CArchive& ar);
	BOOL SHPCreate( const char * pszShapeFile, int nShapeType );
	BOOL SHPCreateW(  const CString & strLayer, int nShapeType );
	void SHPClose();
	int	      DBFAddField( const char * pszFieldName, DBFFieldType eType, int nWidth, int nDecimals );
	
	int       DBFWriteAttribute( int iShape, int iField, INT64 nFieldValue );
	int       DBFWriteAttribute( int iShape, int iField, int nFieldValue );
	int       DBFWriteAttribute( int iShape, int iField, double dFieldValue );
	int       DBFWriteAttribute( int iShape, int iField, const char * pszFieldValue );
	int      DBFWriteAttribute( int iShape, int iField );
	
public:
	int m_nDBFReadTupleLen;
	char * m_pDBFReturnTuple;
	inline BOOL FileExists(const TCHAR* FileName);		/// ���� ���翩�� Ȯ��

	CRITICAL_SECTION m_csQueueLock;
	/* -------------------------------------------------------------------- */
	/*      SHP API Prototypes                                              */
	/* -------------------------------------------------------------------- */
	void       SHPGetInfo(  int * pnEntities, int * pnShapeType,
		double * padfMinBound, double * padfMaxBound );
		
	//void SHPDestroyObject( CSHPObject * psObject );
	
	const char * SHPTypeName( int nSHPType );
	const char * SHPPartTypeName( int nPartType );
	
	SHPTree* SHPCreateTree(  int nDimension, int nMaxDepth,
				double *padfBoundsMin, double *padfBoundsMax, const TCHAR * szQTreeFileName );

	SHPTree * SHPCreateTree(  int nDimension, int nMaxDepth,
                     double *padfBoundsMin, double *padfBoundsMax );
	

	void FillOffset(SHPTree * psTree);
	void FillOffsetToNode(SHPTreeNode * psTreeNode, int* pnSum);

	void    SHPDestroyTree( SHPTree * hTree );
	
	int		SHPWriteTree( SHPTree *hTree, const char * pszFilename );
	SHPTree SHPReadTree( const char * pszFilename );
	
	int	      SHPTreeAddObject( SHPTree * hTree, CSHPObject * psObject );
	int	      SHPTreeAddShapeId( SHPTree * hTree, CSHPObject * psObject );
	int	      SHPTreeRemoveShapeId( SHPTree * hTree, int nShapeId );
	
	void 	SHPTreeTrimExtraNodes( SHPTree * hTree );
	
	int    * SHPTreeFindLikelyShapes( SHPTree * hTree,
		double * padfBoundsMin,
		double * padfBoundsMax,
		int * );
	int     SHPCheckBoundsOverlap( double *, double *, double *, double *, int );
	bool CESRIShapeFile::ReverseVtxOrder(CSHPObject *pShp);
#define XBASE_FLDHDR_SZ       32
	DBFHandle DBFOpen( const char * pszDBFFile, const char * pszAccess );
	//DBFHandle DBFOpenW(const CString & strFileName, const char * pszAccess );

	DBFHandle DBFCreate( const char * pszDBFFile );
	DBFHandle DBFCreateW( const CString & strFilename );
	
		
	const char * DBFReadTuple(int hEntity );
	int       DBFWriteTuple(int hEntity, void * pRawTuple );
	
	DBFHandle       DBFCloneEmpty(const char * pszFilename );
	
	void	      DBFClose();
	char          DBFGetNativeFieldType( int iField );
	
	void ReadTreeNodeFromFile(SHPTreeNode * psTreeNode, CArchive& ar);
	
	void * SfRealloc( void * pMem, int nNewSize );
	void DBFWriteHeader();
	void DBFFlushRecord();
	void* DBFReadAttribute(int hEntity, int iField,char chReqType );
	int DBFWriteAttribute(int hEntity, int iField, void * pValue );
	static inline double GetCrossProduct (GPOINT &sPoint1, GPOINT &sPoint2, GPOINT &sPoint3);
	static BOOL IsPolygonConvex ( double *rgX, double *rgY, int nStartVertex, int nPartVertexCount);
	static BOOL IsPolygonClockWise (double *rgX, double *rgY, int nStartVertex, int nPartVertexCount);

public:
	void SHPTreeCollectShapeIds(SHPTreeNode * psTreeNode,
                        double * padfBoundsMin, double * padfBoundsMax,
                        int * pnShapeCount, int * pnMaxShapes, int* pnMaxNodes,
                        int ** ppanShapeList, int ** ppanOffsetList, int ** ppanCountList, int* pnNodeCount );
private:
	void QuickSort(int* anShapeList, long l, long r);
	void QuickSort2(CString* asValueList, int* anShapeList, long l, long r);
	void BottomSort(int* anShapeList, double* pdBottoms, long l, long r);
	void SwapShapeID(int *i, int *j) ;
	void SwapString(CString *i, CString *j);
	void SwapBottom(double *i, double *j);
	void WriteTreeNodeToFile(SHPTreeNode * psTreeNode, CArchive& ar);
	void SwapWord( int length, void * wordP );

	void	_SHPSetBounds( unsigned char * pabyRec, CSHPObject * psShape );
	void	SHPWriteHeader();
	void SHPDestroyTreeNode( SHPTreeNode * psTreeNode );
	int SHPTreeNodeTrim( SHPTreeNode * psTreeNode );
	CESRIShapeFile::SHPTreeNode *SHPTreeNodeCreate( double * padfBoundsMin,double * padfBoundsMax );
	int SHPTreeNodeAddShapeId( SHPTreeNode * psTreeNode, CSHPObject * psObject,
                       int nMaxDepth, int nDimension );
	int SHPCheckObjectContained( CSHPObject * psObject, int nDimension,
                           double * padfBoundsMin, double * padfBoundsMax );
	void SHPTreeSplitBounds( double *padfBoundsMinIn, double *padfBoundsMaxIn,
                    double *padfBoundsMin1, double * padfBoundsMax1,
                    double *padfBoundsMin2, double * padfBoundsMax2 );


	
};

#endif // !defined(AFX_ESRISHAPEFILE_H__CF8C8C0A_6E29_4E84_A171_091870A43C61__INCLUDED_)

